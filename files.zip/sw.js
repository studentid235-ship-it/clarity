/*
  ╔══════════════════════════════════════════════════════════════╗
  ║   Clarity Club — Service Worker  v5.0                       ║
  ║   Background notifications with system sound + vibration    ║
  ║   UPLOAD THIS FILE to the SAME folder as the HTML file      ║
  ╚══════════════════════════════════════════════════════════════╝
*/

const SW_VER    = 'cc-v6.0';
const CACHE_NM  = 'cc-offline-v6';
const IDB_NM    = 'clarity_club';
const IDB_STORE = 'sw_data';
const IDB_KEY   = 'main';

// ── Install: cache the app HTML for offline ──────────────────────
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NM)
      .then(c => c.addAll(['./clarity-club-vibes.html']).catch(()=>{}))
      .then(() => self.skipWaiting())
  );
});

// ── Activate ─────────────────────────────────────────────────────
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k=>k!==CACHE_NM).map(k=>caches.delete(k))))
      .then(() => self.clients.claim())
      .then(() => loadDataAndCheck())
  );
});

// ── IndexedDB helpers ─────────────────────────────────────────────
function openDB() {
  return new Promise((res,rej) => {
    const r = indexedDB.open(IDB_NM, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(IDB_STORE, {keyPath:'id'});
    r.onsuccess = () => res(r.result);
    r.onerror   = () => rej(r.error);
  });
}
async function saveData(data) {
  try {
    const db = await openDB();
    return new Promise((res,rej) => {
      const tx = db.transaction(IDB_STORE,'readwrite');
      tx.objectStore(IDB_STORE).put({id:IDB_KEY, ...data});
      tx.oncomplete = ()=>res(true);
      tx.onerror    = ()=>rej(tx.error);
    });
  } catch(e){}
}
async function loadData() {
  try {
    const db = await openDB();
    return new Promise(res => {
      const tx = db.transaction(IDB_STORE,'readonly');
      const rq = tx.objectStore(IDB_STORE).get(IDB_KEY);
      rq.onsuccess = () => res(rq.result || null);
      rq.onerror   = () => res(null);
    });
  } catch(e){ return null; }
}

// ── State ─────────────────────────────────────────────────────────
let _s = {
  reminders:[], alarms:[], schedule:{}, customCls:[],
  days:['SUN','MON','TUE','WED','THU','FRI','SAT'],
  fired:{}
};
let _timer   = null;
let _lastMin = -1;

// ── Helpers ──────────────────────────────────────────────────────
const pad   = n => String(n).padStart(2,'0');
const toMin = t => { const [h,m]=(t||'0:0').split(':').map(Number); return h*60+m; };
function nowInfo() {
  const n=new Date();
  return {
    ts: pad(n.getHours())+':'+pad(n.getMinutes()),
    td: n.toISOString().slice(0,10),
    nm: n.getHours()*60+n.getMinutes(),
    dk: (_s.days||[])[n.getDay()]||''
  };
}

// ── Fire a system notification ────────────────────────────────────
// silent:false -> device plays its own notification ringtone
function fire(title, body, tag, vib, sticky) {
  return self.registration.showNotification(title, {
    body,
    vibrate:            vib || [300,100,300,100,600],
    requireInteraction: sticky !== false,
    tag,
    renotify:  true,
    silent:    false,
    actions: [
      { action:'open',    title:'Open App' },
      { action:'dismiss', title:'Dismiss'  }
    ]
  });
}

// ── Tell open app window to play audio tone ───────────────────────
async function tellAppToPlay(tone) {
  try {
    const cs = await self.clients.matchAll({type:'window', includeUncontrolled:true});
    for (const c of cs) c.postMessage({type:'PLAY_TONE', tone});
  } catch(e){}
}

// ── Core check ───────────────────────────────────────────────────
async function checkNow() {
  const {ts,td,nm,dk} = nowInfo();
  if (nm === _lastMin) return;
  _lastMin = nm;
  let dirty = false;

  // Reminders
  for (const r of _s.reminders) {
    const k = 'rem'+r.id+td;
    if (!_s.fired[k] && r.time===ts && (!r.date||r.date===td)) {
      _s.fired[k]=1; dirty=true;
      await fire('Reminder: '+r.tit, r.note||'Time to act!', 'rem'+r.id, [300,100,300,100,600], true);
      await tellAppToPlay(_s.tone||'ringtone');
    }
  }

  // Alarms
  for (const a of _s.alarms) {
    const k = 'alm'+a.id+td+ts;
    if (a.on && !_s.fired[k] && a.time===ts) {
      _s.fired[k]=1; dirty=true;
      await fire('Alarm: '+a.lbl, 'Time: '+ts, 'alm'+a.id, [400,100,400,100,800,100,800], true);
      await tellAppToPlay('alarm');
    }
  }

  // Classes
  const slots = [
    ...(_s.schedule[dk]||[]),
    ...(_s.customCls||[]).filter(c=>c.day===dk)
  ].filter(s => s.t !== 'recess');

  for (const s of slots) {
    const sm = toMin(s.s);

    if (nm === sm-5) {
      const k = 'c5'+s.s+td;
      if (!_s.fired[k]) {
        _s.fired[k]=1; dirty=true;
        await fire(
          s.sub+' in 5 minutes',
          'Class at '+s.s+(s.tea&&s.tea!=='Batch' ? ' — '+s.tea : ''),
          'cls5'+s.s, [200,80,200,80,200], false
        );
        await tellAppToPlay(_s.tone||'ringtone');
      }
    }

    if (nm === sm) {
      const k = 'c0'+s.s+td;
      if (!_s.fired[k]) {
        _s.fired[k]=1; dirty=true;
        const teacher = (s.tea && s.tea!=='Batch') ? s.tea+' — ' : '';
        await fire(
          s.sub+' — Class Starting',
          teacher+'Started at '+s.s,
          'cls'+s.s, [300,100,300,100,600], true
        );
        await tellAppToPlay(_s.tone||'ringtone');
      }
    }
  }

  // Prune old fired keys
  const cutoff = new Date(); cutoff.setDate(cutoff.getDate()-2);
  const cut = cutoff.toISOString().slice(0,10).replace(/-/g,'');
  for (const k of Object.keys(_s.fired)) {
    const m = k.match(/(\d{8})/);
    if (m && m[1] < cut) delete _s.fired[k];
  }

  if (dirty) await saveData(_s);
}

// ── Schedule next minute check ────────────────────────────────────
function schedNext() {
  if (_timer) clearTimeout(_timer);
  const n  = new Date();
  const ms = 60000 - n.getSeconds()*1000 - n.getMilliseconds() + 200;
  _timer = setTimeout(async ()=>{ await checkNow(); schedNext(); }, ms);
}

// ── Load + start clock ────────────────────────────────────────────
async function loadDataAndCheck() {
  const saved = await loadData();
  if (saved) {
    _s = {
      reminders: saved.reminders||[],
      alarms:    saved.alarms   ||[],
      schedule:  saved.schedule ||{},
      days:      saved.days     ||_s.days,
      customCls: saved.customCls||[],
      fired:     saved.fired    ||{},
    };
  }
  await checkNow();
  schedNext();
}

// ── Messages from app ─────────────────────────────────────────────
self.addEventListener('message', e => {
  if (!e.data) return;

  if (e.data.type==='SYNC') {
    _s = {
      reminders: e.data.reminders||[],
      alarms:    e.data.alarms   ||[],
      schedule:  e.data.schedule ||{},
      days:      e.data.days     ||_s.days,
      customCls: e.data.customCls||[],
      tone:      e.data.tone     ||_s.tone||'ringtone',
      fired:     _s.fired        ||{},
    };
    saveData(_s);
    schedNext();
    if (e.source) e.source.postMessage({type:'SYNC_ACK', ver:SW_VER});
  }

  if (e.data.type==='PING') {
    if (e.source) e.source.postMessage({type:'PONG', ver:SW_VER});
  }

  if (e.data.type==='CHECK_NOW') checkNow();

  if (e.data.type==='TEST') {
    fire('Clarity Club — Test', 'Notifications are working! You will hear alerts for classes.', 'cc-test', [300,100,300], true);
  }
});

// ── Fetch: serve cached HTML offline ─────────────────────────────
self.addEventListener('fetch', e => {
  if (e.request.method!=='GET') return;
  if (e.request.mode==='navigate') {
    e.respondWith(
      fetch(e.request)
        .then(res => { caches.open(CACHE_NM).then(c=>c.put(e.request,res.clone())); return res; })
        .catch(() => caches.match(e.request))
    );
    return;
  }
  e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request).catch(()=>c)));
});

// ── Notification tap ──────────────────────────────────────────────
self.addEventListener('notificationclick', e => {
  e.notification.close();
  if (e.action==='dismiss') return;
  e.waitUntil(
    clients.matchAll({type:'window', includeUncontrolled:true}).then(cs => {
      for (const c of cs) {
        if ('focus' in c) {
          c.postMessage({type:'PLAY_TONE', tone:(_s&&_s.tone)||'ringtone'});
          return c.focus();
        }
      }
      return clients.openWindow('./clarity-club-vibes.html');
    })
  );
});

// ── WEB PUSH from server ──────────────────────────────────────────
// Fires when the backend server sends a push — works with phone locked,
// app closed, browser in background. This is the primary notification path.
self.addEventListener('push', event => {
  let data = { title: 'Clarity Club', body: 'Alert', tag: 'cc-push' };
  try { if (event.data) data = event.data.json(); } catch(e) {}
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body:               data.body,
      tag:                data.tag || 'cc-push',
      renotify:           true,
      requireInteraction: true,
      silent:             false,
      vibrate:            [400, 100, 400, 100, 800],
      actions: [
        { action: 'open',    title: 'Open App' },
        { action: 'dismiss', title: 'Dismiss'  }
      ]
    })
  );
});

// ── Background Sync ───────────────────────────────────────────────
self.addEventListener('sync',         e => { if (e.tag==='cc-check')    e.waitUntil(loadDataAndCheck()); });
self.addEventListener('periodicsync', e => { if (e.tag==='cc-periodic') e.waitUntil(loadDataAndCheck()); });

// Kick off immediately
loadDataAndCheck();
