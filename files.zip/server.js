/*
  ╔══════════════════════════════════════════════════════════════════════╗
  ║   Clarity Club — Push Notification Server  v1.0                    ║
  ║   Runs 24/7. Sends Web Push for every class, alarm, and reminder.  ║
  ║   Works even when phone is locked or app is closed.                ║
  ║                                                                    ║
  ║   SETUP (one time):                                                ║
  ║     npm install express cors web-push                              ║
  ║     node server.js                                                 ║
  ║                                                                    ║
  ║   FREE CLOUD HOSTING (runs 24/7 without your laptop):              ║
  ║     1. Create free account at https://render.com                   ║
  ║     2. New → Web Service → connect your GitHub repo                ║
  ║     3. Build cmd: npm install   Start cmd: node server.js          ║
  ║     4. Copy the https://xxxx.onrender.com URL into the app         ║
  ╚══════════════════════════════════════════════════════════════════════╝
*/
const express = require('express');
const cors    = require('cors');
const webpush = require('web-push');
const fs      = require('fs');
const path    = require('path');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const CONFIG_FILE = path.join(__dirname, 'cc-config.json');
const SUBS_FILE   = path.join(__dirname, 'cc-subscriptions.json');
const DATA_FILE   = path.join(__dirname, 'cc-data.json');

// VAPID keys
let config = {};
if (fs.existsSync(CONFIG_FILE)) {
  config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
} else {
  const keys = webpush.generateVAPIDKeys();
  config = { publicKey: keys.publicKey, privateKey: keys.privateKey };
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
  console.log('New VAPID keys generated');
}
webpush.setVapidDetails('mailto:clarity-club@notifications.app', config.publicKey, config.privateKey);

function loadSubs() {
  if (!fs.existsSync(SUBS_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(SUBS_FILE, 'utf8')); } catch { return []; }
}
function saveSubs(s) { fs.writeFileSync(SUBS_FILE, JSON.stringify(s, null, 2)); }

function loadData() {
  if (!fs.existsSync(DATA_FILE)) return { alarms:[], reminders:[], schedule:{}, customCls:[] };
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { return { alarms:[], reminders:[], schedule:{}, customCls:[] }; }
}
function saveData(d) { fs.writeFileSync(DATA_FILE, JSON.stringify(d, null, 2)); }

const DEFAULT_TT = {
  MON:[{s:"10:30",e:"11:30",sub:"EP",tea:"MDI",t:"lecture"},{s:"11:30",e:"12:30",sub:"EG",tea:"VNK",t:"lecture"},{s:"13:00",e:"15:00",sub:"EG1(BJS)/EG2(CPR)/EP3(DMJ)/BEEE4(GRB)",tea:"Batch",t:"batch"},{s:"15:30",e:"16:30",sub:"M-II",tea:"BSP",t:"lecture"}],
  TUE:[{s:"10:30",e:"11:30",sub:"M-II",tea:"BSP",t:"lecture"},{s:"11:30",e:"12:30",sub:"EEE",tea:"SSD",t:"lecture"},{s:"13:00",e:"15:00",sub:"EG3(BJS)/EG4(CPR)/EP2(DMJ)/BEEE1(GRB)",tea:"Batch",t:"batch"},{s:"15:30",e:"16:30",sub:"EG",tea:"VNK",t:"lecture"},{s:"16:30",e:"17:30",sub:"BCME",tea:"NTB",t:"lecture"}],
  WED:[{s:"10:30",e:"12:30",sub:"EP4(VPK)/BEEE2(GRB)",tea:"Batch",t:"batch"},{s:"13:00",e:"14:00",sub:"DT",tea:"BJS",t:"lecture"},{s:"14:00",e:"15:00",sub:"M-II",tea:"BSP",t:"lecture"},{s:"15:30",e:"17:30",sub:"EP1(VPK)/BEEE3(GRB)",tea:"Batch",t:"batch"}],
  THU:[{s:"10:30",e:"11:30",sub:"DT",tea:"BJS",t:"lecture"},{s:"11:30",e:"12:30",sub:"M-II",tea:"BSP",t:"lecture"},{s:"13:00",e:"14:00",sub:"EP",tea:"MDI",t:"lecture"},{s:"14:00",e:"15:00",sub:"BEEE",tea:"GRB",t:"lecture"},{s:"15:30",e:"16:30",sub:"IKSB",tea:"MUR",t:"lecture"},{s:"16:30",e:"17:30",sub:"BCME",tea:"NTB",t:"lecture"}],
  FRI:[{s:"07:00",e:"08:30",sub:"PR NSS II",tea:"MUR",t:"activity"},{s:"10:30",e:"11:30",sub:"BEEE",tea:"GRB",t:"lecture"},{s:"11:30",e:"12:30",sub:"M-II",tea:"BSP",t:"lecture"},{s:"13:00",e:"14:00",sub:"EG",tea:"VNK",t:"lecture"},{s:"14:00",e:"15:00",sub:"EP",tea:"MDI",t:"lecture"},{s:"15:30",e:"16:30",sub:"BCME",tea:"NTB",t:"lecture"},{s:"16:30",e:"17:30",sub:"NSS II",tea:"MUR",t:"activity"}],
  SAT:[{s:"10:30",e:"11:30",sub:"EEE",tea:"SSD",t:"lecture"},{s:"11:30",e:"12:30",sub:"EP",tea:"MDI",t:"lecture"},{s:"13:00",e:"14:00",sub:"EG",tea:"VNK",t:"lecture"},{s:"14:00",e:"15:00",sub:"IKSB",tea:"MUR",t:"lecture"},{s:"15:30",e:"16:30",sub:"BEEE",tea:"GRB",t:"lecture"}]
};

const DAYS = ['SUN','MON','TUE','WED','THU','FRI','SAT'];
function toMin(t) { const [h,m]=(t||'0:0').split(':').map(Number); return h*60+m; }
function pad(n) { return String(n).padStart(2,'0'); }

async function pushAll(title, body, tag) {
  const subs = loadSubs();
  if (!subs.length) return;
  const payload = JSON.stringify({ title, body, tag: tag || 'cc' });
  console.log(`[${new Date().toLocaleTimeString()}] PUSH: "${title}" → ${subs.length} device(s)`);
  const dead = [];
  for (const sub of subs) {
    try { await webpush.sendNotification(sub, payload, { TTL: 3600 }); }
    catch (e) { if (e.statusCode === 404 || e.statusCode === 410) dead.push(sub.endpoint); }
  }
  if (dead.length) saveSubs(subs.filter(s => !dead.includes(s.endpoint)));
}

const _fired = new Set();
async function runScheduler() {
  const n   = new Date();
  const day = DAYS[n.getDay()];
  const nm  = n.getHours()*60 + n.getMinutes();
  const ts  = pad(n.getHours())+':'+pad(n.getMinutes());
  const td  = n.toISOString().slice(0,10);
  const data = loadData();
  const tt   = (data.schedule && Object.keys(data.schedule).length) ? data.schedule : DEFAULT_TT;
  const slots = [...(tt[day]||[]), ...(data.customCls||[]).filter(c=>c.day===day)].filter(s=>s.t!=='recess');

  for (const slot of slots) {
    const sm  = toMin(slot.s);
    const tch = (slot.tea && slot.tea!=='Batch') ? ` (${slot.tea})` : '';
    const k15 = `${td}-c15-${slot.s}`;
    const k5  = `${td}-c5-${slot.s}`;
    const k0  = `${td}-c0-${slot.s}`;
    if (nm===sm-15 && !_fired.has(k15)) { _fired.add(k15); await pushAll(`${slot.sub} in 15 minutes`, `Starts at ${slot.s}${tch} — Get ready!`, 'cls-15'); }
    if (nm===sm-5  && !_fired.has(k5))  { _fired.add(k5);  await pushAll(`${slot.sub} in 5 minutes`,  `Starting at ${slot.s}${tch}`, 'cls-5'); }
    if (nm===sm    && !_fired.has(k0))  { _fired.add(k0);  await pushAll(`${slot.sub} — Starting Now`, `${slot.s}–${slot.e}${tch}`, 'cls-0'); }
  }
  for (const a of (data.alarms||[])) {
    if (!a.on) continue;
    const k = `${td}-alm-${a.id}`;
    if (a.time===ts && !_fired.has(k)) { _fired.add(k); await pushAll(a.lbl||'Alarm', `Alarm at ${a.time}`, 'alarm'); }
  }
  for (const r of (data.reminders||[])) {
    if (r.fired) continue;
    const k = `${td}-rem-${r.id}`;
    if ((r.date||td)===td && r.time===ts && !_fired.has(k)) { _fired.add(k); await pushAll(r.tit, r.note||`Reminder at ${r.time}`, 'rem'); }
  }
  if (nm===0) _fired.clear();
}

setInterval(runScheduler, 30000);

// ── Routes ────────────────────────────────────────────────────────
app.get('/', (_,res) => res.json({ status:'ok', server:'Clarity Club Push', subscribers:loadSubs().length, time:new Date().toISOString() }));

app.get('/vapid-public-key', (_,res) => res.json({ publicKey: config.publicKey }));

app.post('/subscribe', (req, res) => {
  const { subscription, reminders, alarms, schedule, customCls } = req.body;
  if (!subscription?.endpoint) return res.status(400).json({ error:'No subscription' });
  const subs = loadSubs();
  const idx  = subs.findIndex(s => s.endpoint===subscription.endpoint);
  if (idx===-1) { subs.push(subscription); console.log('New subscriber registered'); }
  else subs[idx] = subscription;
  saveSubs(subs);
  if (alarms!==undefined || reminders!==undefined || schedule!==undefined) {
    const ex = loadData();
    saveData({ alarms:alarms??ex.alarms, reminders:reminders??ex.reminders, schedule:schedule??ex.schedule, customCls:customCls??ex.customCls });
  }
  res.json({ ok:true, subscribers:subs.length });
});

app.post('/sync-data', (req, res) => {
  const { reminders, alarms, schedule, customCls } = req.body;
  const ex = loadData();
  saveData({ alarms:alarms??ex.alarms, reminders:reminders??ex.reminders, schedule:schedule??ex.schedule, customCls:customCls??ex.customCls });
  res.json({ ok:true });
});

app.post('/test-push', async (_,res) => {
  const subs = loadSubs();
  if (!subs.length) return res.json({ ok:false, msg:'No subscribers. Open the app and connect first.' });
  await pushAll('Clarity Club — Test Notification', 'Push is working! You will receive class alerts, alarms, and reminders.', 'test');
  res.json({ ok:true, sent:subs.length });
});

app.post('/unsubscribe', (req, res) => {
  saveSubs(loadSubs().filter(s => s.endpoint!==req.body.endpoint));
  res.json({ ok:true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\nClarity Club Push Server running on port ${PORT}`);
  console.log(`VAPID key: ${config.publicKey.slice(0,30)}...`);
  console.log('Waiting for app to connect...\n');
});
